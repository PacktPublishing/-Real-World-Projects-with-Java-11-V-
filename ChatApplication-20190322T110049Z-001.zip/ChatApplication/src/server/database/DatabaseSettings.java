package server.database;

interface DatabaseSettings {
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String DATABASE_URL = "jdbc:mysql://den1.mysql3.gear.host:3306/unichatdatabase";
    String DATABASE_USERNAME = "unichatdatabase";
    String DATABASE_PASSWORD = "Dr1DqCb?~Eoh";
    int PING_INTERVAL = 30000;
}
