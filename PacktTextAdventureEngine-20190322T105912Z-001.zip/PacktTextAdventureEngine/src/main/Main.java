package main;

import gameEngine.item.sampleItems.Rock;
import gameEngine.person.components.npc.Interaction;
import gameEngine.person.components.npc.NPC;
import gameEngine.player.Player;
import gameEngine.room.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Room entrance = new Room();
        Interaction instructorDialog = new Interaction("Sup",
                "Go to the room on the right and give me the" +
                        " rock you find on the floor there, please.");
        List<Interaction> instructorInteractions = new ArrayList<>();
        instructorInteractions.add(instructorDialog);
        NPC instructor = new NPC("Instructor", entrance,
                instructorInteractions);
        entrance.addPerson(instructor);

        Room roomWithRock = new Room();
        roomWithRock.addItem(new Rock());

        roomWithRock.setRoomToTheLeft(entrance);
        entrance.setRoomToTheRight(roomWithRock);

        Player player = new Player(entrance);

        String userInput;
        do {
            Scanner scanner = new Scanner(System.in);
            userInput = scanner.nextLine();
            System.out.println(player.takeCommand(userInput));
            if (instructor.getItem("Rock") != null) {
                System.out.println("You win");
                break;
            }
        } while (!userInput.toUpperCase().equals("EXIT"));
    }
}
