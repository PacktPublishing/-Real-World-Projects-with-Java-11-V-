package gameEngine.player;

import gameEngine.Physical;
import gameEngine.PhysicalType;
import gameEngine.person.components.npc.NPC;
import gameEngine.person.Person;
import gameEngine.item.Item;
import gameEngine.room.Room;

import java.util.List;

public class Player extends Person {

    public Player(Room currentRoom) {
        this("Player", currentRoom);
    }

    public Player(String name, Room currentRoom) {
        super(name, currentRoom);
    }

    public Player(String name, List<Item> starterItems, Room currentRoom) {
        super(name, starterItems, currentRoom);
    }

    public String takeCommand(String originalCommand) {
        String[] commandParts = originalCommand.split(" ");
        String command = commandParts[0];
        try {
            String item = commandParts[1]; // can also be an npc to talk to
            if (command.toUpperCase().equals("TELL"))
                return tellCommand(commandParts);
            if (command.toUpperCase().equals("PICK"))
                return pickCommand(commandParts);
            try {
                String target = commandParts[2];
                return commandWithTarget(command, item, target);
            } catch (IndexOutOfBoundsException e) {
                return normalCommand(command, item); 
            }
        } catch (IndexOutOfBoundsException e) {
            return basicCommand(command);
        }
    }

    private String basicCommand(String command) {
        switch (command.toUpperCase()) {
            case "RIGHT":
                return super.moveToRightRoom();
            case "LEFT":
                return super.moveToLeftRoom();
            default:
                return "There is no such command";
        }
    }
    
    private String tellCommand(String[] commandParts) {
        try {
            String npc = commandParts[1];
            String input = commandParts[2];
            return tellCommand(npc, input);
        } catch (IndexOutOfBoundsException e) {
            return "You said nothing";
        }
    }

    private String pickCommand(String[] commandParts) {
        try {
            String item = commandParts[1];
            return pickCommand(item);
        } catch (IndexOutOfBoundsException e) {
            return "You said nothing";
        }
    }

    private String tellCommand(String npc, String input) {
        Physical physical = super.getCurrentRoom().getPhysical(npc);
        if (physical == null ||
                physical.getPhysicalType() != PhysicalType.NPC) {
            return "This is not a character";
        } else {
            NPC npcToTalkTo = (NPC) physical;
            return npcToTalkTo.interact(input);
        }
    }

    private String pickCommand(String item) {
        Physical physical = super.getCurrentRoom().getPhysical(item);
        if (physical == null
                || physical.getPhysicalType() != PhysicalType.ITEM) {
            return "This is not an item";
        } else {
            Item itemToPickUp = (Item) physical;
            super.getCurrentRoom().removeItem(itemToPickUp);
            super.addItem(itemToPickUp);
            return "Picked up " + itemToPickUp.getName();
        }
    }
    
    private String normalCommand(String command, String item) {
        Physical physical = super.getCurrentRoom().getPhysical(item);
        if (physical.getPhysicalType() != PhysicalType.ITEM) {
            return "This is not an item";
        } else {
            Item itemToUse = (Item) physical;
            return itemToUse.use(this, command);
        }
    }
    
    private String commandWithTarget(String command, String item,
                                     String target) {
        Item itemToUse = super.getItem(item);
        if (itemToUse == null) {
            return "This is not an item";
        } else {
            Physical targetPhysical =
                    super.getCurrentRoom().getPhysical(target);
            if (targetPhysical == null) {
                return "No target called '" + target + "'";
            } else {
                return itemToUse.useWithTarget(this, command,
                        targetPhysical);
            }
        }
    }

    @Override
    public PhysicalType getPhysicalType() {
        return null; // There will be no other player,
        // therefore we don't need a special type for a Player class.
    }
}
