package gameEngine.room;

import gameEngine.Physical;
import gameEngine.PhysicalType;
import gameEngine.person.Person;
import gameEngine.item.Inventory;
import gameEngine.item.Item;

import java.util.ArrayList;
import java.util.List;

public class Room implements Physical { // There is only one dimension to move in
    private Room roomToTheRight;
    private Room roomToTheLeft;
    private List<Person> persons; // both NPC's and the player itself
    private Inventory inventory;

    public Room() {
        this(new ArrayList<>());
    }

    public Room(List<Person> persons) {
        this.roomToTheRight = null;
        this.roomToTheLeft = null;
        this.inventory = new Inventory();
        this.persons = persons;
    }

    public Physical getPhysical(String name) { // get something in the room
        for (Person person:persons) {
            if (person.getName().toUpperCase()
                    .equals(name.toUpperCase())) return person;
        }

        return inventory.findItemByName(name);
        // IMPORTANT: even if 'inventory.findItemByName(name)' is
        // null that is ok - that is what we would have returned
        // if we didn't find the item nowhere, and since the 'inventory'
        // is the last place we check, null is a good return too.
    }

    public void addPerson(Person character) {
        this.persons.add(character);
    }

    public void removePerson(Person character) {
        this.persons.remove(character);
    }

    public Room getRoomToTheRight() {
        return roomToTheRight;
    }

    public void removeItem(Item item) {
        inventory.removeItem(item);
    }

    public void addItem(Item item) {
        inventory.addItem(item);
    }

    public Room getRoomToTheLeft() {
        return roomToTheLeft;
    }

    public void setRoomToTheRight(Room roomToTheRight) {
        this.roomToTheRight = roomToTheRight;
    }

    public void setRoomToTheLeft(Room roomToTheLeft) {
        this.roomToTheLeft = roomToTheLeft;
    }

    @Override
    public PhysicalType getPhysicalType() {
        return PhysicalType.ROOM;
    }
}
