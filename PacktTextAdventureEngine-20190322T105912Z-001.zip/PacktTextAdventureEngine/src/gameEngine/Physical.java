package gameEngine;

public interface Physical { // Just used to generalize all physical things
    PhysicalType getPhysicalType();
}
