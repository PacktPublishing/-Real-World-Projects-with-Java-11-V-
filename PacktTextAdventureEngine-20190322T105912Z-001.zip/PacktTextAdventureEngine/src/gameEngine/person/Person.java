package gameEngine.person;

import gameEngine.Physical;
import gameEngine.item.Inventory;
import gameEngine.item.Item;
import gameEngine.room.Room;

import java.util.ArrayList;
import java.util.List;

public abstract class Person implements Physical {
    private String name;
    private Inventory inventory;
    private Room currentRoom;

    public Person(String name, Room currentRoom) {
        this(name, new ArrayList<>(), currentRoom);
    }

    public Person(String name, List<Item> starterItems, Room currentRoom) {
        this.name = name;
        this.inventory = new Inventory();
        for (Item item:starterItems) {
            inventory.addItem(item);
        }
        this.currentRoom = currentRoom;
    }

    public String moveToRightRoom() {
        if (currentRoom.getRoomToTheRight() != null) {
            currentRoom.removePerson(this);
            currentRoom = currentRoom.getRoomToTheRight();
            currentRoom.addPerson(this);
            return "Moved to the room on the right";
        } else {
            return "There is no room on the right";
        }
    }

    public String moveToLeftRoom() {
        if (currentRoom.getRoomToTheLeft() != null) {
            currentRoom.removePerson(this);
            currentRoom = currentRoom.getRoomToTheLeft();
            currentRoom.addPerson(this);
            return "Moved to the room on the left";
        } else {
            return "There is no room on the left";
        }
    }

    public void removeItem(Item item) {
        inventory.removeItem(item);
    }

    public void addItem(Item item) {
        inventory.addItem(item);
    }

    public Item getItem(String item) {
        return inventory.findItemByName(item);
    }

    public String getName() {
        return name;
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }
}
