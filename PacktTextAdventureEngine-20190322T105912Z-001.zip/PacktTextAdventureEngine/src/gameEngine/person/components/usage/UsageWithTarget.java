package gameEngine.person.components.usage;

import gameEngine.Physical;
import gameEngine.person.Person;
import gameEngine.item.Item;

public abstract class UsageWithTarget {

    private String command;

    public UsageWithTarget(String command) {
        this.command = command;
    }

    public boolean use(String command) {
        return command.toUpperCase().equals(this.command.toUpperCase());
    }

    public abstract String result(Person using, Item item, Physical target);
}
