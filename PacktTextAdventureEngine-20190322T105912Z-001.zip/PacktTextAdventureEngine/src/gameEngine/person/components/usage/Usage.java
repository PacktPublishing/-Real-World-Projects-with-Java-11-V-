package gameEngine.person.components.usage;

import gameEngine.person.Person;
import gameEngine.item.Item;

public abstract class Usage {
    private String command; // The command to trigger to use this usage

    public Usage(String command) {
        this.command = command;
    }

    public boolean use(String command) {
        return command.toUpperCase().equals(this.command.toUpperCase());
    }

    public abstract String result(Person using, Item item);
}
