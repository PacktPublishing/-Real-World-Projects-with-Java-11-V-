package gameEngine.person.components.usage.sampleUsages;

import gameEngine.person.Person;
import gameEngine.item.Item;
import gameEngine.person.components.usage.Usage;

public class DropUsage extends Usage {
    public DropUsage() {
        super("drop");
    }

    @Override
    public String result(Person using, Item item) {
        using.removeItem(item);
        using.getCurrentRoom().addItem(item);
        return "The item was dropped";
    }
}
