package gameEngine.person.components.usage.sampleUsages;

import gameEngine.Physical;
import gameEngine.PhysicalType;
import gameEngine.person.Person;
import gameEngine.item.Item;
import gameEngine.person.components.usage.UsageWithTarget;

public class GiveUsage extends UsageWithTarget {

    public GiveUsage() {
        super("give");
    }

    @Override
    public String result(Person using, Item item, Physical target) {
        using.removeItem(item);
        if (target.getPhysicalType() == PhysicalType.NPC) {
            Person targetPerson = (Person) target;
            targetPerson.addItem(item);
            return "You have given the item to " + targetPerson.getName();
        }
        return "You can't give an item to this " + target.getPhysicalType();
    }
}
