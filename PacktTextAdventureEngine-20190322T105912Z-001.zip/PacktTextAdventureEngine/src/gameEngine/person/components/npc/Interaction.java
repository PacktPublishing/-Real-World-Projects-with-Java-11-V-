package gameEngine.person.components.npc;

public class Interaction { // describes a Verbal npc
    private String input;
    private String output;

    public Interaction(String input, String output) {
        this.input = input;
        this.output = output;
    }

    public String checkActivate(String input) {
        if (input.toUpperCase().equals(this.input.toUpperCase()))
            return output;
        else return null;
    }
}
