package gameEngine.person.components.npc;

import gameEngine.PhysicalType;
import gameEngine.person.Person;
import gameEngine.item.Item;
import gameEngine.room.Room;

import java.util.ArrayList;
import java.util.List;

public class NPC extends Person {

    private List<Interaction> interactions;

    public NPC(String name, Room currentRoom, List<Interaction> interactions) {
        this(name, new ArrayList<>(), currentRoom, interactions);
    }

    public NPC(String name, List<Item> starterItems, Room currentRoom,
               List<Interaction> interactions) {
        super(name, starterItems, currentRoom);
        this.interactions = interactions;
    }

    public String interact(String inputSaying) {
        for (Interaction interaction:interactions) {
            if (interaction.checkActivate(inputSaying) != null) {
                return interaction.checkActivate(inputSaying);
            }
        }
        return "I don't know what to say";
    }

    @Override
    public PhysicalType getPhysicalType() {
        return PhysicalType.NPC;
    }
}
