package gameEngine;

public enum PhysicalType {
    ITEM("Item"),
    ROOM("Room"),
    NPC("Character");

    private final String name;

    PhysicalType(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
