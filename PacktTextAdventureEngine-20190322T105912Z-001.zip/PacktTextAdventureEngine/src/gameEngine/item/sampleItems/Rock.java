package gameEngine.item.sampleItems;

import gameEngine.item.Item;
import gameEngine.person.components.usage.Usage;
import gameEngine.person.components.usage.UsageWithTarget;
import gameEngine.person.components.usage.sampleUsages.DropUsage;
import gameEngine.person.components.usage.sampleUsages.GiveUsage;

import java.util.ArrayList;
import java.util.List;

public class Rock extends Item { // Just a simple example of a very common item

    public Rock() {
        this("Rock");
    }

    public Rock(String name) {
        super(name, generateRockUsages(), generateRockUsagesWithTargets());
    }

    private static List<Usage> generateRockUsages() {
        List<Usage> usages = new ArrayList<>();
        usages.add(new DropUsage());
        return usages;
    }

    private static List<UsageWithTarget> generateRockUsagesWithTargets() {
        List<UsageWithTarget> usages = new ArrayList<>();
        usages.add(new GiveUsage());
        return usages;
    }
}
