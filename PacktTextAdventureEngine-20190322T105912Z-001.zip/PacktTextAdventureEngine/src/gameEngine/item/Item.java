package gameEngine.item;

import gameEngine.Physical;
import gameEngine.PhysicalType;
import gameEngine.person.Person;
import gameEngine.person.components.usage.Usage;
import gameEngine.person.components.usage.UsageWithTarget;

import java.util.List;

public abstract class Item implements Physical {

    private static final String NONE = "No such usage.";

    private String name;
    private List<Usage> usages;
    private List<UsageWithTarget> usagesWithTargets;

    public Item(String name, List<Usage> usages,
                List<UsageWithTarget> usagesWithTargets) {
        this.name = name;
        this.usages = usages;
        this.usagesWithTargets = usagesWithTargets;
    }

    public String use(Person using, String command) {
        for (Usage usage:usages) {
            if (usage.use(command)) {
                return usage.result(using, this);
            }
        }
        return NONE;
    }

    public String useWithTarget(Person using, String command, Physical target) {
        for (UsageWithTarget usage:usagesWithTargets) {
            if (usage.use(command)) {
                return usage.result(using, this, target);
            }
        }
        return NONE;
    }

    public String getName() {
        return name;
    }

    @Override
    public PhysicalType getPhysicalType() {
        return PhysicalType.ITEM;
    }
}
