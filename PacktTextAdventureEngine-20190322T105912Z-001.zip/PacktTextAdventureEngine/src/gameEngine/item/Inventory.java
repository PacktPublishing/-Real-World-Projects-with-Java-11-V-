package gameEngine.item;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Item> items;

    public Inventory() {
        this.items = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public Item findItemByName(String name) {
        for (Item item:items) {
            if (item.getName().toUpperCase()
                    .equals(name.toUpperCase())) return item;
        }
        return null;
    }
}
